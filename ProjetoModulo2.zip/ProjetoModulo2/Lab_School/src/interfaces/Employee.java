package interfaces;

public interface Employee {
    public String funcionarios();
    public void atendimentoPedagogicoRealizado();
}
