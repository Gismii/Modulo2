package interfaces;

public interface Student {

    public int receberAtendimento(int id);

    public String getCondicaoUM();


    public void setCondicaoUM(String condicaoUM);



    public double getNota();


    public void setNota();
}
