package interfaces;

public interface Teacher {


    public String getFormacaoAcademica();


    public void setFormacaoAcademica(String formacaoAcademica);


    public String getExperienciaDesenvolvimento();

    public void setExperienciaDesenvolvimento(String experienciaDesenvolvimento);

        public String getEstado ();


    }
